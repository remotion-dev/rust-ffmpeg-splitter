/*	MacDLLMain.c	*/

int
main()
{
	return	0;
}
